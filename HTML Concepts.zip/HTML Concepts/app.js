// variables ==> to store data

// var username = "John"
// let age = 30
// const country = "USA"

// console.log(username)
// console.log(age)
// console.log(country)

// const country = "USA"
// console.log(country)

// country = "Canada"
// console.log(country)



// let country = "USA"
// console.log(country)

// country = "Canada"
// console.log(country)


// var country = "USA"
// console.log(country)

// country = "Canada"
// console.log(country)

// let vs var

// let is block scoped(let variables are accessible only withitn the block only) 
// but var is global scoped

//  {} ==> block

// for(var i = 0; i < 10; i++)
// {
//     console.log(i)
// }

// console.log(i)

// ===============================================

// let empName = "Mary"
// let empAge = 30
// let empCountry = "USA"
// let empDesignation = "Software Engineer"   

// console.log(`The name of the employee is ${empName}, age is ${empAge}, country is ${empCountry} and designation is ${empDesignation}`)


// back ticks 



// let city = "Canada" // string
// let city = 'Canada' // string
// Anything kept Within single or double quotes ==> STRING

// let age = 40 // Number
// let salary = 35000.00 // Number

// let age = 40
// console.log(typeof age)

// let city = "New York"
// console.log(typeof city)

// booleans ==> true and false

// let hasCar = true
// console.log(typeof hasCar)

// in javascriot, if we dont give the vaalue to a , then the default value is undefined

// let username = "John"
// let age = 30
// let country = "USA"
// let salary

// console.log(username)
// console.log(age)
// console.log(country)
// console.log(salary)

// write a program to store the names of 5 students

// let student1 = "John"
// let student2 = "Raju"
// let student3 = "Rani"
// let student4 = "Ramu"
// let student5 = "Mary"

// Arrays ==> can be used to store multiple values

// javascript ==> []


// const studentNames = [ "John", "Raju", "Rani", "Ramu", "Mary" ]
// console.log(studentNames[1])

// const fitnessData = [ "stepsTaken", 2000, "caloriesBurned", 500, "distanceCovered", 1 ]

// console.log(fitnessData)

// NOTE: we will use arrays concept whenever we want to store the 
// data imdividually where there is no connception betwween any e
//lmenets

// In javascript, key value pairs will be kept within {}
// [] ==> array
// {} ==> object


// const fitnessData = [ "stepsTaken", 2000, "caloriesBurned", 500, "distanceCovered", 1 ]

// Whenever we want to store data in key value pairs, we will use objects

// const fitnessData = {
//     "stepsTaken" : 2000, 
//     "caloriesBurned" : 500, 
//     "distanceCovered" : 1
// }

// console.log(fitnessData)



// let num1 = 10
// let num2 = 20
// let result1 = num1 + num2
// console.log(result1)

// let num3 = 30
// let num4 = 40
// let result2 = num3 + num4
// console.log(result2)

// let num5 = 50
// let num6 = 60
// let result3 = num5 + num6
// console.log(result3)




// functions concepts

// how to create a function in javascript
// in javascrpt, there are 3 ways to create a function

// 1. function declaration
// 2. function expression
// // 3. arrow function




// function addNumbers()
// {
//     let num1 = 10
//     let num2 = 20
//     let result = num1 + num2
//     console.log(result)
// }

// addNumbers()


// FUNCTION DELARATION

// function add(num1, num2) // variables ==> parameters
// { 
//     let result = num1 + num2
//     console.log(result)
// }

// add(10, 20) // values ==> arguments


// function add(num1, num2, num3) // variables ==> parameters
// { 
//     let result = num1 + num2 + num3
//     console.log(result)

// }

// add(10, 20, 30, 40) // values ==> arguments


// function add(num1, num2, num3, num4) // variables ==> parameters
// { 
//     let result = num1 + num2 + num3 + num4
//     console.log(result)

// }

// add(10, 20, 30) // values ==> arguments

// // NaN ==> Not a Number


// function add(num1, num2, num3)
// {
//     let result = num1 + num2 + num3
//     return result
// }


// const output = add(100, 200, 300)
// console.log(output)

// // access that 600?



// Write a program to multiple eadh element in the array by 3
// const numbers = [ 10, 20, 30, 40, 50, 60, 70, 80 ] 

// // in jvascript, if we want to perform same operation on each element
// // of the array, then we use forEach()

// numbers.forEach(function(ele, index, arr)
// {
//     console.log(a, b, c)
// })
 



// WAP to divide each element in the array by 2
// const numbers = [ 10, 20, 30, 40, 50, 60, 70, 80 ]

// numbers.forEach(function(ele, index)
// {
//     console.log(ele / 2)
// })



// inout ==> [ 10, 20, 30, 40, 50, 60, 70, 80 ]
// output ==> [ 5, 10, 15, 20, 25, 30, 35, 40 ]

// If the input is in ARRAY and we want outout not in ARRAY ==> forEach()
// If the input is in ARRAY and we want outout in ARRAY ==> map()

// forEach() and map() ==> 99.99% same

// forEach() ==> same operation on each element of the array
// map() ==> same operation on each element of the array
// forEach() ==> output will not be in array
// map() ==> output will be in array




// const numbers = [ 10, 20, 30, 40, 50, 60, 70, 80 ]

// const result = numbers.map(function(ele, index)
// {
//     return ele / 2
// })


// console.log(result)

// const numbers = [ 10, 20, 30, 40, 50, 60, 70, 80 ]

// const result = numbers.forEach(function(ele, index)
// { 
//     return ele / 2
// })


// console.log(result)


// [ 10, 20, 30, 40, 50, 60, 70, 80 ] ==> [ 25, 30, 35, 40]

// const numbers = [ 10, 20, 30, 40, 50, 60, 70, 80 ]

// const result = numbers.map(function(ele, index)
// { 
//   if(ele > 45)
//   {
//     return ele / 2
//   }
// })

// console.log(result)


// const numbers = [ 10, 20, 30, 40, 50, 60, 70, 80 ]

// const result = numbers.filter(function(ele, index)
// { 
//   if(ele > 45)
//   {
//     return ele / 2
//   }
// })


// const numbers = [ 10, 20, 30, 40, 50, 60, 70, 80 ]

// const result = numbers.filter(function(ele)
// {
//     if(ele > 45)
//     {
//         return ele
//     }
// }).map(function(ele)
// {
//     return ele / 2
// })

// console.log(result)


// in arrow functions, if there is only one statement
// for that one statement return is optional
// for that one statement {} are also optional

// [ 10, 20, 30, 40, 50, 60, 70, 80 ] ==> 130

// const numbers = [ 10, 20, 30, 40, 50, 60, 70, 80 ]
// const result = numbers.filter((ele) => ele > 45).map((ele) => ele / 2)
// // result ==> [25, 30, 35, 40] ==> 130 ==> reduce()
// const output = result.reduce(function(accumulator, nextValue)
// {
//     return a + b
// })
 
// console.log(output)
 

