
// write the code ==> COLLECTING THE TASK
// write the code ==> DISPLAYING THE TASK


// write the code ==> COLLECTING THE TASK
// Javscript should always check whether the Add Task button is 
// clicked OR Not
// OR
// Javascript should always listen to click action

// document ==> HTML file ==> index.html

const AddButton = document.getElementById("add")
const HtmlBody = document.getElementById("body")

AddButton.addEventListener("click", function(a)
{
    a.preventDefault()
    // Collect the Task
    let capaturedTask = document.getElementById("task").value
    
    const H3tag = document.createElement("h3") // <h3></h3>
    H3tag.textContent = capaturedTask // <h3>Playing</h3>

    HtmlBody.append(H3tag)
   

    document.getElementById("task").value = ""
})